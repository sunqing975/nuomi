export default { render: (ctx) => `<div class="weather-card">${ctx.result}</div>` }
