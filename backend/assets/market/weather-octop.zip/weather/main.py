def setup(ctx):
    def weather_query(city: str) -> str:
        return f"{city} 当前多云，24°C（示例数据）"
    ctx.tool("weather_query", weather_query, description="查询指定城市当前天气")
